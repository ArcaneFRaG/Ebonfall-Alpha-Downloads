This is a safe local dummy test package for Ebonfall Launcher v0.1.
