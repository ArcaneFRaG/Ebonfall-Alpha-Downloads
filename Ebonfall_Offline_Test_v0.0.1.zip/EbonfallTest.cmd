@echo off
title Ebonfall Dummy Playtest Build
echo.
echo  EBONFALL - OFFLINE TEST BUILD 0.0.1
echo  Launcher installation and Play worked.
echo  No actual Ebonfall game files are included.
echo.
pause
